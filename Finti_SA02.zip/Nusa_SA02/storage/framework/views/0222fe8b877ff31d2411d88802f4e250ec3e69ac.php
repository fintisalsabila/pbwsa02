
<?php $__env->startSection("isi"); ?>
<h3>Data Mata Kuliah</h3>
<a href="/mk/tambah">Tambah</a>
<table class="table table-striped table-hover">
    <thead>
        <tr>
        <th>Kode</th>
        <th>Nama</th>
        <th>SKS</th>
        <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $mk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($i->kode); ?></td>
            <td><?php echo e($i->nama); ?></td>
            <td><?php echo e($i->sks); ?></td>
            <td>
            <a href="/mk/ubah/<?php echo e($i->id); ?>">Ubah</a> |
            <a href="/mk/hapus/<?php echo e($i->id); ?>">Hapus</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<!--1321053 - NUSA PUTRA PRATAMA-->
<?php echo $__env->make("tema.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwsa02\Nusa_SA02\resources\views/matakuliah.blade.php ENDPATH**/ ?>