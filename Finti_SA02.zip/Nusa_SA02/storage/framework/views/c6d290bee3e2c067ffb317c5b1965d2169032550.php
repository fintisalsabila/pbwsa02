
<?php $__env->startSection("isi"); ?>
<h3>Tambah Data Mahasiswa</h3>
<form method="post" action="/mhs">
<?php echo csrf_field(); ?>
<div class="form-group">
    <label for="nim">NIM:</label>
    <input type="number" class="form-control" id="nim" name="nim" 
        placeholder="isi NIM"/>
</div>
<div class="form-group">
    <label for="nama">Nama Lengkap:</label>
    <input type="text" class="form-control" id="nama" name="nama"
        placeholder="isi nama"/>
</div>
<button type="submit" class="btn btn-success">Tambah</button>
<button type="button" class="btn btn-danger"
    onclick="history.go(-1)">Batal</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("tema.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwsa02\Nusa_SA02\resources\views/mahasiswa_tambah.blade.php ENDPATH**/ ?>