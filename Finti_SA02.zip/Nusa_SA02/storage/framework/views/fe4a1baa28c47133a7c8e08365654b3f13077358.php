<div class="row">
            <div class="col-sm-12 small text-center border p-2 my-1">
                Copyright &copy; Nusa Putra Pratama - 2023
            </div>
        </div>


        <!--1321053 - NUSA PUTRA PRATAMA--><?php /**PATH C:\xampp\htdocs\pbwsa02\Nusa_SA02\resources\views/tema/footer.blade.php ENDPATH**/ ?>