
<?php $__env->startSection("isi"); ?>
<h3>Data Mahasiswa</h3>
<a href="/mhs/tambah">Tambah</a>
<table class="table table-striped table-hover">
    <thead>
        <tr>
        <th>NIM</th>
        <th>Nama Lengkap</th>
        <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $mhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($i->nim); ?></td>
            <td><?php echo e($i->nama); ?></td>
            <td>
            <a href="/mhs/ubah/<?php echo e($i->id); ?>">Ubah</a> |
            <a href="/mhs/hapus/<?php echo e($i->id); ?>">Hapus</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("tema.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwsa02\Nusa_SA02\resources\views/mahasiswa.blade.php ENDPATH**/ ?>