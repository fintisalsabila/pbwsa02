<html>
<head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('bootstrap.min.css')); ?>">
        <!-- Latest compiled JavaScript -->
        <script src="<?php echo e(asset('jquery-3.4.1.min.js')); ?>"></script>
        <script src="<?php echo e(asset('popper.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap.min.js')); ?>"></script>
        <style type="text/css">
            table.table-hover tbody tr:hover {                
                 background-color: lightgoldenrodyellow;
            }
        </style>   

</head>
    <body>
<?php echo $__env->make("tema.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-sm-fluid">
        <div class="row">
            <div class="col-sm-12">
                <?php echo $__env->yieldContent("isi"); ?>
            </div>
        </div>
        <?php echo $__env->make("tema.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       
    </div>
    </body>
</html>

<!--1321053 - NUSA PUTRA PRATAMA--><?php /**PATH C:\xampp\htdocs\pbwsa02\Nusa_SA02\resources\views/tema/layout.blade.php ENDPATH**/ ?>