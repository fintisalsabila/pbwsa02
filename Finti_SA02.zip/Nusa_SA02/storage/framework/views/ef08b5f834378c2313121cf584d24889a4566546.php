
<?php $__env->startSection("isi"); ?>
<h3>Hapus Data Mahasiswa</h3>
<form method="post" action="/mhs/<?php echo e($m->id); ?>">
<?php echo csrf_field(); ?> <?php echo method_field("DELETE"); ?>
<div class="form-group">
    <label for="nim">NIM: <?php echo e($m->nim); ?></label>
</div>
<div class="form-group">
    <label for="nama">Nama Lengkap: <?php echo e($m->nama); ?></label>
</div>
<button type="submit" class="btn btn-success">Hapus</button>
<button type="button" class="btn btn-danger" 
    onclick="history.go(-1)">Batal</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("tema.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwsa02\Nusa_SA02\resources\views/mahasiswa_hapus.blade.php ENDPATH**/ ?>