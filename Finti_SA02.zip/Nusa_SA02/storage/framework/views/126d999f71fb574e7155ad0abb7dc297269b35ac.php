
<?php $__env->startSection("isi"); ?>
<h3>Tambah Data MataKuliah</h3>
<form method="post" action="/mk">
<?php echo csrf_field(); ?>
<div class="form-group">
    <label for="kode">Kode:</label>
    <input type="number" class="form-control" id="kode" name="kode" 
        placeholder="isi Kode"/>
</div>
<div class="form-group">
    <label for="nama">Nama:</label>
    <input type="text" class="form-control" id="nama" name="nama"
        placeholder="isi Nama"/>
</div>
<div class="form-group">
    <label for="sks">SKS:</label>
    <input type="number" class="form-control" id="sks" name="sks"
        placeholder="isi SKS"/>
</div>
<button type="submit" class="btn btn-success">Tambah</button>
<button type="button" class="btn btn-danger"
    onclick="history.go(-1)">Batal</button>
</form>
<?php $__env->stopSection(); ?>

<!--1321053 - NUSA PUTRA PRATAMA-->
<?php echo $__env->make("tema.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwsa02\Nusa_SA02\resources\views/matakuliah_tambah.blade.php ENDPATH**/ ?>