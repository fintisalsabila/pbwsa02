@extends("tema.layout")
@section("isi")
<h3>Tambah Data Mahasiswa</h3>
<form method="post" action="/mhs">
@csrf
<div class="form-group">
    <label for="nim">NIM:</label>
    <input type="number" class="form-control" id="nim" name="nim" 
        placeholder="isi NIM"/>
</div>
<div class="form-group">
    <label for="nama">Nama Lengkap:</label>
    <input type="text" class="form-control" id="nama" name="nama"
        placeholder="isi nama"/>
</div>
<button type="submit" class="btn btn-success">Tambah</button>
<button type="button" class="btn btn-danger"
    onclick="history.go(-1)">Batal</button>
</form>
@endsection

<!--1321053 - NUSA PUTRA PRATAMA-->