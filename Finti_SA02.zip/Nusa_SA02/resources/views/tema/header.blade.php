<nav class="navbar navbar-expand-sm bg-primary navbar-dark">
        <a class="navbar-brand" href="index.html">STMI</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="/mhs">Mahasiswa</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/mk">MataKuliah</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/transkip">Transkip Nilai</a>
            </li>    
            </ul>
</div>
        </nav>

        <!--1321053 - NUSA PUTRA PRATAMA-->